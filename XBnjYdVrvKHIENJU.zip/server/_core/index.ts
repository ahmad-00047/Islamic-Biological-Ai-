import "dotenv/config";
import express from "express";
import { createServer } from "http";
import { createExpressMiddleware } from "@trpc/server/adapters/express";
import { registerOAuthRoutes } from "./oauth";
import { publicPlatformScript } from "./publicConfig";
import { appRouter } from "../routers";
import { createContext } from "./context";
import { serveStatic, setupVite } from "./vite";

async function startServer() {
  const app = express();
  const server = createServer(app);
  // Configure body parser with larger size limit for file uploads
  app.use(express.json({ limit: "50mb" }));
  app.use(express.urlencoded({ limit: "50mb", extended: true }));
  app.get("/api/health", (_req, res) => res.json({ status: "ok" }));
  app.get("/api/platform/config.js", (_req, res) => {
    res.set("Cache-Control", "no-store").type("application/javascript").send(publicPlatformScript());
  });
  app.post("/api/ai/chat", async (req, res) => {
    const { message, className, mode, history } = req.body ?? {};
    if (typeof message !== "string" || !message.trim()) {
      return res.status(400).json({ answer: "Please enter a question." });
    }
    const fallback = `Aap ka sawal ${className ?? "selected class"} ke context mein hai. Is first learning preview mein AI service connect hone par detailed jawab, step-by-step explanation aur source cards show honge. Filhaal is topic ko apni study library mein save karein.`;
    const baseUrl = process.env.MANUS_API_URL;
    const apiKey = process.env.MANUS_API_KEY;
    if (!baseUrl || !apiKey) return res.json({ answer: fallback, source: "IBAI learning guide" });
    try {
      const response = await fetch(`${baseUrl}/v1/chat/completions`, {
        method: "POST",
        headers: { Authorization: `Bearer ${apiKey}`, "Content-Type": "application/json" },
        body: JSON.stringify({
          messages: [
            { role: "system", content: "You are Islamic Biological AI, a calm educational tutor for BISE Bahawalpur classes 9-12. Default to Roman Urdu/Roman English and reply in the user's language. Explain Biology accurately and progressively. For Islamic questions, be respectful, avoid sectarian debate, cite Quran and authentic Hadith or clearly label scholarly interpretation, and never invent references. For reproductive biology, marriage, intimacy, puberty and sexual-health topics, be age-appropriate, modest, medically accurate and safety-conscious. Do not claim to replace a qualified teacher, doctor or mufti. Structure answers with a short answer, explanation, and sources when relevant." },
            ...Array.isArray(history) ? history.slice(-6) : [],
            { role: "user", content: `${mode ?? "Tutor"} mode. ${className ?? ""}. Question: ${message.trim()}` },
          ],
        }),
      });
      const data = await response.json();
      const answer = data?.choices?.[0]?.message?.content;
      if (typeof answer === "string" && answer.trim()) return res.json({ answer, source: "AI tutor · verify references before formal use" });
      return res.json({ answer: fallback, source: "IBAI learning guide" });
    } catch (error) {
      console.error("[AI] chat failed", error);
      return res.json({ answer: fallback, source: "IBAI learning guide" });
    }
  });
  registerOAuthRoutes(app);
  // tRPC API
  app.use(
    "/api/trpc",
    createExpressMiddleware({
      router: appRouter,
      createContext,
    })
  );
  // development mode uses Vite, production mode uses static files
  if (process.env.NODE_ENV === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }

  const port = Number(process.env.PORT || "3000");
  if (!Number.isInteger(port) || port < 1 || port > 65535) throw new Error("Invalid PORT");
  server.on("error", error => { console.error("Server failed:", error.message); process.exit(1); });
  server.listen(port, "0.0.0.0", () => console.log(`Server listening on port ${port}`));
}

startServer().catch(error => { console.error(error); process.exit(1); });
