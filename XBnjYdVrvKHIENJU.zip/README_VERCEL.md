# Islamic Biological AI — Vercel Deployment

## 1. Import
Vercel Dashboard → Add New Project → Import Git Repository, or upload this project folder. Do not upload `node_modules`.

## 2. Build settings
- Framework: Vite (or Other)
- Build command: `pnpm build`
- Output directory: `dist/public`
- Install command: `pnpm install --frozen-lockfile`

## 3. AI key settings
Open **Project → Settings → Environment Variables**. Add these variables for Production, Preview and Development:

- `OPENAI_API_KEY` = your own OpenAI-compatible API key
- `OPENAI_API_BASE` = `https://api.openai.com/v1` (or your compatible provider URL)
- `AI_MODEL` = `gpt-4o-mini` (change only if your provider supports another model)

The key stays server-side in `/api/ai/chat`; never put it in HTML, React code, Git, or a public ZIP. Redeploy after saving variables.

## 4. Test
Open the deployed URL, ask “Cell kya hota hai?”, and confirm the AI answer appears. If the app says the AI service is not configured, check the variable names and redeploy.

## 5. Play Store next step
Use the deployed HTTPS URL in an Android WebView/PWA wrapper or native Android project. Play Store release requires a signed `.aab`, privacy policy URL, Data Safety declaration, content rating, screenshots and testing.

This project contains original educational notes and a tutor interface. It does not copy a publisher textbook, bypass BISE CAPTCHA, or include a secret API key.
