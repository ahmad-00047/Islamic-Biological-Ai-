export default {
  logoUrl: "https://placehold.co/256x256/0f766e/f8fafc.png?text=IBAI",
};
