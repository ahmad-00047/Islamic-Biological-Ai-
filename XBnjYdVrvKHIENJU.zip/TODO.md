# Islamic Biological AI — TODO

## Launch identity and mobile-first workspace
- [ ] Opening splash visibly presents “Deol Studio presents Islamic Biological AI”.
- [ ] Main workspace is usable on phone screens and includes chat, study, Islam, tools and Pro Library navigation.
- [ ] Roman English/Roman Urdu is the default and the UI exposes a language state with same-language answer behavior.

## AI tutor and references
- [ ] User can ask natural-language Biology, Islamic or mixed questions and receive a structured answer.
- [ ] Biology answers support BISE Bahawalpur classes 9–12 and use age-appropriate explanations.
- [ ] Islamic answers show reference/source cards and avoid sectarian debate; scholarly differences are labeled.
- [ ] The app has safe guidance for reproductive biology, marriage and intimacy questions.

## Voice experience
- [ ] User can start/stop voice input where the browser supports SpeechRecognition, with a clear text fallback.
- [ ] User can play/stop spoken answers using browser speech synthesis.

## Study system
- [ ] Class 9, 10, 11 and 12 curriculum cards exist with chapter maps, original summaries, key concepts, practice and MCQ prompts.
- [ ] User can open notes, mark progress, bookmark topics and launch quiz mode.
- [ ] Curriculum is editable for future official BISE Bahawalpur 2026–27 notifications.

## Pro Library
- [ ] Premium packs and advanced features show locked states and a payment/unlock call to action.
- [ ] No copyrighted textbook is reproduced without a license; original notes are available in the base app.

## Delivery
- [ ] `manus-routes.json` is served for the application routes.
- [ ] TypeScript diagnostics pass and the development server serves the app on the configured port.
- [ ] A project zip is created only after the working build is complete.
