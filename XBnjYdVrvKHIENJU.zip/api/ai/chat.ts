type VercelRequest = { method?: string; body?: any };
type VercelResponse = { status(code: number): VercelResponse; json(body: unknown): void };

const systemPrompt = "You are Islamic Biological AI, an English-first educational tutor for BISE Bahawalpur classes 9-12. Answer only the user's actual latest question. NEVER begin with Assalam-o-alaikum, Wa alaikum assalam, hello, welcome, or any automatic greeting unless the user explicitly greets you first. Keep normal answers short: usually 3–6 clear lines or concise bullets, not an essay. Use English by default, but detect the language/script of the latest question and answer in that same language, including Urdu, Roman Urdu, Arabic, or English. Explain Biology accurately. For Islamic questions, be respectful, non-sectarian, cite Quran/authentic Hadith only when relevant or requested, and never invent references. For health or reproductive topics, be age-appropriate, modest, medically accurate and safety-conscious. Do not repeat the question or add an unrelated introduction. Only add detailed sources when asked or when the answer needs them.";

export default async function handler(req: VercelRequest, res: VercelResponse) {
  if (req.method !== "POST") return res.status(405).json({ error: "Method not allowed" });
  const { message, className, mode, history, imageData, imageMimeType } = req.body ?? {};
  if ((typeof message !== "string" || !message.trim()) && typeof imageData !== "string") return res.status(400).json({ answer: "Please enter a question or upload an image." });
  if (typeof imageData === "string" && imageData.length > 8_000_000) return res.status(413).json({ answer: "Please upload a smaller image (maximum 6 MB)." });
  const baseUrl = process.env.OPENAI_API_BASE || process.env.MANUS_API_URL || "https://api.openai.com/v1";
  const apiKey = process.env.OPENAI_API_KEY || process.env.MANUS_API_KEY;
  if (!apiKey) return res.status(503).json({ answer: "AI service is not configured yet. Add OPENAI_API_KEY in Vercel Environment Variables." });
  try {
    const endpoint = baseUrl.replace(/\/$/, "").endsWith("/v1") ? `${baseUrl.replace(/\/$/, "")}/chat/completions` : `${baseUrl.replace(/\/$/, "")}/v1/chat/completions`;
    const userText = (message || "Read the image carefully. Transcribe any visible text or question, identify its language, and answer it in that same language. If the image is unclear, say exactly what is unreadable.").trim();
    const userContent = typeof imageData === "string"
      ? [{ type: "text", text: `${mode ?? "Tutor"} mode. ${className ?? ""}. ${userText}` }, { type: "image_url", image_url: { url: imageData }}]
      : userText;
    const upstream = await fetch(endpoint, {
      method: "POST",
      headers: { Authorization: `Bearer ${apiKey}`, "Content-Type": "application/json" },
      body: JSON.stringify({ model: process.env.AI_MODEL || "gpt-4o-mini", temperature: 0.2, max_tokens: 350, messages: [
        { role: "system", content: systemPrompt },
        ...(Array.isArray(history) ? history.slice(-6) : []),
        { role: "user", content: userContent },
      ] }),
    });
    const data = await upstream.json();
    const rawAnswer = data?.choices?.[0]?.message?.content;
    if (typeof rawAnswer !== "string" || !rawAnswer.trim()) return res.status(502).json({ answer: "The AI service did not return a usable answer. Please try again." });
    const answer = rawAnswer.trim().replace(/^(w\.?\s*sal(aam|am)|w\.?\s*alaikum\s*sal(aam|am)|wa\s*alaikum\s*ass?alam|wal(a|i)kum\s*sal(aam|am)|assalam\s*o\s*alaikum|وعلیکم\s*السلام|السلام\s*علیکم|hello|hi|welcome)[!,.،۔:\- ]*/i, "").trim();
    return res.status(200).json({ answer, source: "AI tutor · verify references before formal use" });
  } catch (error) {
    console.error("Vercel AI proxy error", error);
    return res.status(502).json({ answer: "The AI service could not be reached. Please try again." });
  }
}
