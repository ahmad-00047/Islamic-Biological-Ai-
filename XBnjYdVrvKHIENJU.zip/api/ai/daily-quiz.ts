type VercelRequest = { method?: string; body?: any };
type VercelResponse = { status(code: number): VercelResponse; json(body: unknown): void };

type Question = { question: string; options: string[]; answer: number; explanation: string };

export default async function handler(req: VercelRequest, res: VercelResponse) {
  if (req.method !== "POST") return res.status(405).json({ error: "Method not allowed" });
  const { date, className, runId } = req.body ?? {};
  const apiKey = process.env.OPENAI_API_KEY || process.env.MANUS_API_KEY;
  const base = (process.env.OPENAI_API_BASE || process.env.MANUS_API_URL || "https://api.openai.com/v1").replace(/\/$/, "");
  if (!apiKey) return res.status(503).json({ error: "AI service is not configured." });
  const day = typeof date === "string" ? date : new Date().toISOString().slice(0, 10);
  const topic = typeof className === "string" ? className : "Classes 9–12";
  const prompt = `Generate exactly 100 NEW Biology multiple-choice questions for ${topic}, based on BISE Bahawalpur/Punjab secondary and higher-secondary Biology topics. This is a fresh generation run for ${day}; unique run seed: ${String(runId || Date.now())}. Do not repeat questions or wording from any earlier run, even if the topic is similar. Cover different chapters and difficulty levels. Return ONLY valid JSON: {"questions":[{"question":"...","options":["...","...","...","..."],"answer":0,"explanation":"..."}]}. answer must be the zero-based correct option index. Questions must be scientifically accurate, age-appropriate, original, and not copied from a publisher textbook.`;
  try {
    const endpoint = base.endsWith("/v1") ? `${base}/chat/completions` : `${base}/v1/chat/completions`;
    const upstream = await fetch(endpoint, { method: "POST", headers: { Authorization: `Bearer ${apiKey}`, "Content-Type": "application/json" }, body: JSON.stringify({ model: process.env.AI_MODEL || "gpt-4o-mini", temperature: 0.9, messages: [{ role: "system", content: "You generate accurate educational Biology question banks. Follow the requested JSON format exactly." }, { role: "user", content: prompt }] }) });
    const data = await upstream.json();
    const raw = data?.choices?.[0]?.message?.content;
    const parsed = JSON.parse(typeof raw === "string" ? raw.replace(/^```json\s*|\s*```$/g, "") : "{}");
    const questions = Array.isArray(parsed.questions) ? parsed.questions.filter((q: Question) => typeof q?.question === "string" && Array.isArray(q.options) && q.options.length === 4 && Number.isInteger(q.answer)).slice(0, 100) : [];
    if (questions.length < 100) return res.status(502).json({ error: "The daily question set was incomplete. Please try again." });
    return res.status(200).json({ date: day, questions });
  } catch (error) {
    console.error("Daily quiz generation error", error);
    return res.status(502).json({ error: "Could not generate today's new quiz." });
  }
}
