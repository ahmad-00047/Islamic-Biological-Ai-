# Islamic Biological AI — Implementation Plan

## Scope

Islamic Biological AI is a phone-first educational web app for BISE Bahawalpur students in classes 9–12. The launch screen presents “Deol Studio presents Islamic Biological AI”. Roman English/Roman Urdu is the default, while the assistant detects the user's language and replies in the same language. Voice input and browser voice output are included with text fallback.

## Product structure

- **Home/chat**: conversational tutor with Biology, Islam and mixed-question modes, class selector, example prompts, source cards, voice controls and responsible-use notice.
- **Study**: class 9, 10, 11 and 12 curriculum map with original chapter summaries, key concepts, practice questions, MCQs, revision prompts and progress controls.
- **Islamic knowledge**: reference-aware answers with Quran and Hadith/source cards; avoid sectarian argument and label scholarly differences.
- **Tools**: quiz, notes, bookmarks and progress dashboard.
- **Pro Library**: locked premium study packs and advanced tools. Payment wiring is represented as a safe locked state in this first build; no real charge is taken without a later explicit payment setup.
- **AI service**: server-side proxy to Manus platform chat completions, with a domain-specific system prompt and fallback demo answers when the service is unavailable.

## Design direction

Three possible directions: scholarly emerald study room (0.07), dark laboratory notebook (0.05), and warm madrasa library (0.08). Choose scholarly emerald study room.

Core principles: calm trust, quick scanning, respectful knowledge, and mobile comfort. Use an emerald/ink/cream palette with small gold accents to connect learning and Islamic scholarship without ornamental excess. Use a distinctive left-edge “knowledge spine” on cards, soft rounded panels, and a launch mark combining a leaf and open-book line motif. Keep chat and study actions thumb-reachable, with visible states for language, voice and sources.

Brand essence: a trustworthy Roman-English learning companion connecting Biology and Islamic guidance. Personality: calm, clear, responsible. Brand voice: “Sawal poochain, samajh kar seekhain.” and “Har jawab ke sath source aur context.” Wordmark: compact “IBAI” monogram formed by an open book and leaf. Signature color: deep emerald #0F766E.

## Technical approach

Use the initialized React/Express/tRPC/Drizzle app. Replace the starter Home page with a single-page responsive workspace and use an Express API endpoint for AI chat. Use browser SpeechRecognition when available for voice input and SpeechSynthesis for voice output. Keep the browser-safe experience usable without login. Add a route manifest for `/` and `/404`, project metadata, and a database-ready schema extension later for chats, bookmarks and progress.

## Content constraints

Do not reproduce publisher textbooks without permission. Create original syllabus-aligned notes and study guides. Keep the curriculum map editable because BISE Bahawalpur’s official 2026–27 chapter-level document was not found during initial verification. Cite official board pages and mark any provisional chapter map as updateable. Reproductive biology and intimacy content must remain age-appropriate, modest, medically accurate and safety-conscious.
